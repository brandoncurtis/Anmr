#!/usr/bin/python2.7

#snapshot 7

from __future__ import division
from threading import Thread
import shutil
import gobject
import signal
import struct
import gc

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.figure import Figure
from matplotlib.backends.backend_gtkagg import FigureCanvasGTKAgg as FigureCanvas
from matplotlib.backends.backend_gtkagg import NavigationToolbar2GTKAgg as NavigationToolbar

from anmr_common import *

PROG_NAME=TEMP_DIR+"/funcgen-prog.txt"
TMP_DATA=TEMP_DIR+"/funcgen-data.txt"
RAW_DATA=TEMP_DIR+"/funcgen-data.raw"

#time we allow play to run before starting data acquisition.
AUDIO_PLAY_DELAY=0.05
#capture frequency for audio
AUDIO_FREQ=48000

#how long to read for live view/sweep measurements:
#for arduino at 1/104us per point:
NUM_SAMPLES=1024
#NUM_SAMPLES=2048
#for sound card:
AUDIO_DUR="0:00.11"
#AUDIO_DUR="0:00.22"

gtk.gdk.threads_init()

mode = 'soundcard' 

def remove_lockfile():
	print 'removing lockfile'

	try:
		os.remove(LOCKFILE)
	except:
		pass

class myStreamThread(Thread):

	def __init__ (self, main):

		Thread.__init__(self)
		self.main = main

	def run (self):
#always pass AUDIO_DUR to get_data, but it only uses it for soundcard. For the arduino, it is set by the program
#downloaded earlier.
		if mode == 'arduino':
			rate = 1/float(TIME_STEP)
		else:
			rate = AUDIO_FREQ
		
		while self.main.live == True:
			self.main.streamWin.tyvals = self.main.get_data(AUDIO_DUR)

                        # is it possible that the number of points varies for audio capture?
			if self.main.streamWin.tyvals.size != self.main.streamWin.txvals.size or self.main.streamWin.rate != rate:
				print ' in run, calculating xvals'
				self.main.streamWin.calcXvals(self.main.streamWin.tyvals.size,rate)
			print ' streaming, got: ',self.main.streamWin.tyvals.size,' points'
			#calculate the spectrum too
			self.main.streamWin.fyvals = numpy.abs(numpy.fft.rfft(self.main.streamWin.tyvals)/self.main.streamWin.txvals.size)

			#then plot it, and we're done.
			if self.main.streamWin.tyvals != None: #didn't get any data.
				gobject.idle_add(self.main.streamWin.updatePlot)
		return 

#used for noise and sweep acquisition.  Just runs play and get_data is a separate thread, and deposits the data
class getDataThread(Thread):

	def null(self): #dummy routine for idle_add.  This unblocks the main_iteration call that blocks.
		return

	def __init__ (self, main, duration):

		Thread.__init__(self)
		self.main = main
		self.duration = duration
		self.doneFlag = False
		self.data = None

	def run (self):
		self.main.play()
		self.data = self.main.get_data(self.duration)
		self.main.killPlay()
		self.doneFlag =True
		gobject.idle_add(self.null)
		return

class plotWindow:
#multipurpose plot window used for live streaming, sweep, and noise spectrum
	def __init__(self,title,tfbutton = False):
		#title is the title of the window.

		self.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
		self.window.set_icon_from_file("/usr/local/share/Anmr/FuncGen-icon.svg")
		vbox = gtk.VBox(False)
		self.window.add(vbox)
		self.window.set_size_request(600,400)
		self.window.set_title(title)
		
		self.fig = Figure(figsize=(4,3), dpi=100)
		self.ax = self.fig.add_subplot(111)
		self.ax.set_position([0.2, 0.2, 0.7, 0.7])
		self.canvas = FigureCanvas(self.fig)  # a gtk.DrawingArea
		vbox.pack_start(self.canvas, True, True)
		
#		toolbar = NavigationToolbar(self.canvas, self.window)
		toolbar = MyToolbar(self.canvas, self.window)
		vbox.pack_start(toolbar, False, False)
		
		hbox = gtk.HBox(True)
		vbox.pack_start(hbox, False)
		self.lowerLim = gtk.Label()
		hbox.pack_start(self.lowerLim)
		self.upperLim = gtk.Label()
		hbox.pack_start(self.upperLim)
		self.RMSLabel = gtk.Label()
		hbox.pack_start(self.RMSLabel)
		if tfbutton:
			self.tfbutton = gtk.ToggleButton("Time/Freq")
			self.tfbutton.connect_object("clicked",self.timeFreq,None)
			hbox.pack_start(self.tfbutton)
		
		self.saveButton = gtk.Button("Save")
		vbox.pack_start(self.saveButton,False)
		self.saveButton.connect_object("clicked", self.save,None)

#data stored here:
		self.txvals = None
		self.tyvals = None
		self.fxvals = None
		self.fyvals = None
# time or freq domain?
		self.view = "freq"
#initial limits 
		self.txlims = None
		self.tylims = None
		self.fxlims = None
		self.fylims = None

	def calcXvals(self, np, rate):
		self.txvals = numpy.arange(np)/float(rate)*1000
		self.fxvals = numpy.fft.fftfreq(np,1/float(rate))[0:np//2+1]
		if self.fxvals[-1] < 0:
			self.fxvals[-1] *= -1
		self.rate = rate

	def timeFreq(self,button):
#change from time to freq domain or back
		if self.tfbutton.get_active() and self.view == 'time':
			self.view = 'freq'
			self.txlims = self.ax.get_xlim()
			self.tylims = self.ax.get_ylim()
			if self.fxlims == None:
				min = numpy.amin(self.fxvals)
				max = numpy.amax(self.fxvals)
				(min,max) = calc_lims(min,max)

				self.ax.set_xlim((min,max))

				min = numpy.amin(self.fyvals)
				max = numpy.amax(self.fyvals)
				(min,max) = calc_lims(min,max)

				self.ax.set_ylim((min,max))
			else:
				self.ax.set_xlim(self.fxlims)
				self.ax.set_ylim(self.fylims)
			self.ax.set_xlabel("Frequency (Hz)")
			self.ax.set_ylabel("Amplitude")

			self.line.set_data(self.fxvals,self.fyvals)
			self.canvas.draw_idle()
			
		elif not self.tfbutton.get_active() and self.view == 'freq': # going to time tomain
			self.view = 'time'
			self.fxlims = self.ax.get_xlim()
			self.fylims = self.ax.get_ylim()
			if self.txlims == None:

				min = numpy.amin(self.txvals)
				max = numpy.amax(self.txvals)
				(min,max) = calc_lims(min,max)

				self.ax.set_xlim((min,max))

				min = numpy.amin(self.tyvals)
				max = numpy.amax(self.tyvals)
				(min,max) = calc_lims(min,max)

				self.ax.set_ylim((min,max))

			else:
				self.ax.set_xlim(self.txlims)
				self.ax.set_ylim(self.tylims)
			self.ax.set_xlabel("Time (ms)")
			self.ax.set_ylabel("Amplitude")

			self.line.set_data(self.txvals,self.tyvals)
			self.canvas.draw_idle()
		return

#used for live streaming and noise spectrum
	def updatePlot(self): 

		if self.view == 'time':
			self.line.set_data(self.txvals,self.tyvals)
			rms = numpy.sqrt(numpy.sum(self.tyvals *self.tyvals )/self.tyvals.size)
			self.RMSLabel.set_text("rms: "+str(round(rms,2)))
			self.lowerLim.set_text("min: "+str(round(numpy.amin(self.tyvals))))
			self.upperLim.set_text("max: "+str(round(numpy.amax(self.tyvals))))
		else:
			maxindex = numpy.argmax(self.fyvals)
			self.RMSLabel.set_text("")
			self.lowerLim.set_text("max: "+str(round(self.fyvals[maxindex],2)))
			self.upperLim.set_text("at: "+str(round(self.fxvals[maxindex],1))+" Hz")
			self.line.set_data(self.fxvals,self.fyvals)
		self.canvas.draw_idle()
		return False

	def save(self, dummy):
		# make a copy of the data so we get what we asked for.

		if self.view == 'time':
			yvals = self.tyvals.copy()
			xvals = self.txvals.copy()
		else:
			yvals = self.fyvals.copy()
			xvals = self.fxvals.copy()

		fileChooser = gtk.FileChooserDialog(title = "Save file...", parent=None, action=gtk.FILE_CHOOSER_ACTION_SAVE, buttons=("Cancel",gtk.RESPONSE_CANCEL,"Save", gtk.RESPONSE_OK ))
		response = fileChooser.run()
		fileName = fileChooser.get_filename()
		fileChooser.destroy()

		if response == gtk.RESPONSE_CANCEL:
			return
		elif response == gtk.RESPONSE_OK:
			if fileName[-4:] != ".txt":
				fileName = fileName + ".txt"
			try:	#check if fileName exists
				inFile = open(fileName, "r")
				inFile.close()
				#prompt if want to overwrite
				dialog = gtk.Dialog("Attention!")
				label = gtk.Label("Duplicate file found! Overwrite?")
				dialog.vbox.pack_start(label)
				dialog.add_buttons("Yes", gtk.RESPONSE_YES, "No", gtk.RESPONSE_NO)
				dialog.show_all()
				response = dialog.run()	# -8 is yes, and -9 is no
				dialog.hide()
				dialog.destroy()
				if (response == -8 ):	#delete stuff
	 				try:
						os.remove(fileName)
					except:		#meh.
						pass
				elif (response == -9):	#do not overwrite. abort
					return
			except:	#file does not currently exist. Okay.
				pass
			#save
			outFile = open(fileName,"w")
			for i in range(xvals.size):	#assuming they're of the same length
				outFile.write(str(xvals[i]) + ' ' + str(yvals[i]) + '\n')
			outFile.close()
			return
		else:
			return

class topWin:

	def wrapper(self, widget, null):
		self.killPlay()
		self.liveView.set_active(False)
		gtk.main_quit()

	def __init__(self):

		self.pid = None
		self.wave = None
		self.playing = None
		self.prevRadBut = "off"
		self.live= None
		self.saveSweepSteps = 40
		self.saveNoiseTime = 1

		window = gtk.Window(gtk.WINDOW_TOPLEVEL)	#creates a new window
		window.set_icon_from_file("/usr/local/share/Anmr/FuncGen-icon.svg")

		window.set_size_request(400,300)
		window.set_title("Function Generator/Spectrometer")
		window.connect("delete_event", self.wrapper)
		self.window = window

		hbox = gtk.HBox()
		window.add(hbox)

		leftVbox = gtk.VBox()
		hbox.pack_start(leftVbox)
		rightVbox = gtk.VBox()
		hbox.pack_start(rightVbox)

		thbox=gtk.HBox()
		rightVbox.pack_start(thbox)
		label = gtk.Label("Waveform:")
		thbox.pack_start(label)

		combobox = gtk.combo_box_new_text()
        	combobox.append_text('Sine')
        	combobox.append_text('Square')
        	combobox.append_text('Triangular')
        	combobox.append_text('White Noise')
        	combobox.connect('changed', self.changed_cb)
        	combobox.set_active(0)
		thbox.pack_start(combobox)

		self.comboBox = combobox

		radButton = gtk.RadioButton(None, "Off")
		radButton.connect("toggled", self.radButtonChanged, "off")
		rightVbox.pack_start(radButton)
		self.rad1 = radButton

		radButton = gtk.RadioButton(radButton, "Function Generator")
		radButton.connect("toggled", self.radButtonChanged, "funcGen")
		rightVbox.pack_start(radButton)
		self.rad2 = radButton

		radButton = gtk.RadioButton( radButton, "Measure Using Frequency Sweep")
		radButton.connect("toggled", self.radButtonChanged, "freqSweep")
		rightVbox.pack_start(radButton)
		self.rad3 = radButton

		radButton = gtk.RadioButton( radButton, "Measure Using White Noise")
		radButton.connect("toggled", self.radButtonChanged, "whiteNoise")
		rightVbox.pack_start(radButton)
		self.rad4 = radButton

		thbox=gtk.HBox()
		rightVbox.pack_start(thbox)
		label = gtk.Label("Signal Source:")
		thbox.pack_start(label)

		combobox = gtk.combo_box_new_text()
        	combobox.append_text('Arduino')
        	combobox.append_text('Soundcard')
        	combobox.connect('changed', self.changed_sig_source)
		self.sourceCB=combobox
		thbox.pack_start(combobox)
		
		freqStepView = gtk.Label("Number of Frequency Steps")
		self.freqStepLabel = freqStepView
		self.freqStepAdjustment = gtk.Adjustment(40,2,200,1)
		self.freqStepButton = gtk.SpinButton(self.freqStepAdjustment)
		self.freqStepButton.set_sensitive(False)


		rightVbox.pack_start(freqStepView)
		rightVbox.pack_start(self.freqStepButton)

		goButton = gtk.Button("Go")
		goButton.connect_object("clicked", self.go, True)
		goButton.set_sensitive(False)

		self.goButton = goButton

		rightVbox.pack_end(goButton)


		startFreqView = gtk.Label("Start Frequency")
		self.startFreqAdjust = gtk.Adjustment(200, 1, 9000,100)
		startFreqSpin = gtk.SpinButton(self.startFreqAdjust)

		endFreqView = gtk.Label("End Frequency")
		self.endFreqAdjust = gtk.Adjustment(4000, 200, 9000,1000)
		endFreqSpin = gtk.SpinButton(self.endFreqAdjust)

		startVal = startFreqSpin.get_value_as_int()
		endVal = endFreqSpin.get_value_as_int()
		stepVal = self.freqStepButton.get_value_as_int()

		freqLabel = gtk.Label("Frequency")
		self.freqAdjust = gtk.Adjustment(startVal, startVal, endVal, stepVal, 10*stepVal)

		self.freqAdjust.connect("value-changed", self.freqChanged, True)
		self.startFreqAdjust.connect("value-changed", self.limitChanged, True)
		self.endFreqAdjust.connect("value-changed", self.limitChanged, True)

		self.freq = self.freqAdjust.get_value()

		freqSpinButton = gtk.SpinButton(self.freqAdjust, self.freqAdjust.get_step_increment(), 1)
		freqSlider = gtk.HScale(self.freqAdjust)

		liveView = gtk.ToggleButton("Live View")
		self.liveView = liveView

		leftVbox.pack_start(freqLabel)
		leftVbox.pack_start(freqSpinButton)
		leftVbox.pack_start(freqSlider)

		leftVbox.pack_start(liveView)
	
		leftVbox.pack_end(endFreqSpin)
		leftVbox.pack_end(endFreqView)
		leftVbox.pack_end(startFreqSpin)
		leftVbox.pack_end(startFreqView)

		self.freq1 = freqSpinButton
		self.freq2 = freqSlider
		self.freq3 = startFreqSpin
		self.freq4 = endFreqSpin
		window.show_all()

		#build the streamwindow
		streamWin = plotWindow("Live View",tfbutton=True)
		streamWin.window.connect("delete_event", self.streamKilled)

		liveView.connect("clicked", self.cmstream,streamWin)

		#plot zeros for now
		streamWin.ax.set_xlim([0,100])
		streamWin.ax.set_xlabel("Time (ms)")
		streamWin.ax.set_ylabel("Amplitude")
		streamWin.calcXvals(NUM_SAMPLES,1/float(TIME_STEP))
		streamWin.tyvals = numpy.zeros(NUM_SAMPLES)
		streamWin.fyvals = numpy.zeros(streamWin.fxvals.size)
		streamWin.view = 'time'
		streamWin.line = Line2D(streamWin.txvals,streamWin.tyvals)
		streamWin.ax.add_line(streamWin.line)

		self.streamWin = streamWin

        	combobox.set_active(0) #sets to arduino, and sets default ylimits for streamWin

	def runLast(self): # just does a runProgram - used when we want to turn off the arduino outputs, used with sendProgram ( . , False)
		call = C_PROG_BIN_PATH + './runProgram '+SERIAL_PTY+' ' + TMP_DATA 
		retVal = os.system(call) // 256
		print("doing runLast")
		os.remove( TMP_DATA  )	#<dalek>	EXTERMI		
		if retVal != 1: # Houston, we have a problem
			popup_msg("Error communicating with arduino, return value: "+str(retVal))
			return None 


	def sendProgram(self,readings,start):

		try:
			inFile = open(PROG_NAME, "r")	#if this succeeds, it currently exists
			inFile.close()
			os.remove( PROG_NAME )	#<dalek>	EXTERMINATE, EXTERMINATE	</dalek>
		except:
			pass	#then does not exist, good

		outFile = open(PROG_NAME, "w")		#make new file
		outFile.write("PULSE_PROGRAM\n")		#pulse program identifier
		os.chmod(PROG_NAME,0666) # so anyone can delete it.

#copy the header file:
		try:				      
			headFile = open(PROG_DIR + HEADER_NAME, 'r')
			header = headFile.read()
			headFile.close()
			outFile.write(header)
		except:
			pass

		
# ugh - hardcoded pin assignments...
		outFile.write("CHANGE_PIN %polarise_enable 0\n")	#
		outFile.write("CHANGE_PIN %short_rec_coil 0\n")
		if start == True:
			outFile.write("CHANGE_PIN %short_pol_coil 1\n")	#
			outFile.write("CHANGE_PIN %transmitter_connect 1\n")	#
			outFile.write("CHANGE_PIN %receiver_connect 1\n")
			outFile.write("DELAY_IN_MS 2\n")	        #wait for relays
			outFile.write("READ_DATA 0 0 1 "+str(readings)+"\n")      
		else:
			outFile.write("CHANGE_PIN %short_pol_coil 0\n")	#
			outFile.write("CHANGE_PIN %transmitter_connect 0\n")	#
			outFile.write("CHANGE_PIN %receiver_connect 0\n")
			print "writing file to disable output"

		outFile.write("DELAY_IN_MS 2\n")	        #wait for relays
		outFile.close()

		retVal = ( os.system(C_PROG_BIN_PATH + './compAndDown ' + SERIAL_PTY + ' '+ PROG_NAME) )
		retVal = retVal//256
		if (retVal > 128):				#then it's a negative number
				retVal = retVal - 256		#this is a correction factor
		if (retVal != 1):				#then trouble!
			#grey out the live view and go buttons
			popup_msg("problem downloading program to arduino")
			return False
		return True


	def setRadState(self, state):
		self.rad1.set_sensitive(state)
		self.rad2.set_sensitive(state)
		self.rad3.set_sensitive(state)
		self.rad4.set_sensitive(state)

	def streamKilled(self, event, meh):
#		self.live = False # cmstream will do this
		self.wasLive = False #  in case we're doing a sweep
		self.liveView.set_active(False)
		return True

	def cmstream(self, button,streamWin):
		#this is the call back for the live view button
        #here we start the acquisitions in a separate thread
		if button.get_active():
			#draw the window:
			if mode == "arduino":
                        #check lock, download program.
				if not checkArduino(self.window):
					button.set_active(False)
					return True
				if not self.sendProgram(NUM_SAMPLES,True):
					popup_msg("problem talking to arduino")
					button.set_active,False
					
					return True
				#create the lockfile
				lFile  = open(LOCKFILE,"w")
				lFile.close()
				os.chmod(LOCKFILE,0666) 
				
			streamWin.window.show_all()
			self.live = True
			self.sourceCB.set_sensitive(False)
			self.streamThread = myStreamThread(self)
			self.streamThread.start()
		else:
			self.sourceCB.set_sensitive(True)
			streamWin.window.hide()
			if self.live:
				self.live = False
				self.streamThread.join()
				if mode == 'arduino':
					self.sendProgram(0,False)
					self.runLast()
					remove_lockfile()


		return True

	def get_data(self, duration):
#duration is how long we read for. It only matters for sound card, for arduino it is set by the program downloaded earlier
#it is a string

		if mode == "arduino":
			#delete old data file if we can
			try:
				inFile = open(TMP_DATA, "r")	#if this succeeds, it currently exists
				inFile.close()
				os.remove( TMP_DATA  )	#<dalek>	EXTERMINATE, EXTERMINATE	</dalek>
			except:
				pass	#then does not exist, good

		        #run flashed program
			call = C_PROG_BIN_PATH + './runProgram '+SERIAL_PTY+' ' + TMP_DATA 
			retVal = os.system(call) // 256
			if retVal != 1: # Houston, we have a problem
				popup_msg("Error communicating with arduino, return value: "+str(retVal))
				return None 
				
			(data,scans) = readAFile(TMP_DATA)
			os.chmod(TMP_DATA,0666) # so anyone can delete it.

		else:
			if not os.path.isdir(TEMP_DIR):
			        try:
					os.mkdir(TEMP_DIR)
					os.chmod(TEMP_DIR,0777) 
				except:
					popup_msg("problem creating directory: "+TEMP_DIR)
					return None
			call="rec -c 1 -r "+str(AUDIO_FREQ)+" "+RAW_DATA +" trim 0 "+duration
			os.system(call)
			inFile = open(RAW_DATA, "r")
			data = numpy.fromfile(inFile,dtype=numpy.int16)
			inFile.close()
			os.chmod(RAW_DATA,0666) # so anyone can overwrite it.

			#throw away a few samples at the start
			if data.size > 50:
				data = data[50:]
		data = data - numpy.average(data)
		return data

	def go(self,true):

		#disable most of ui while sweeping or noise-ing
		self.liveView.set_sensitive(False)
		self.sourceCB.set_sensitive(False)
		self.setRadState(False)
		self.goButton.set_sensitive(False)

		#if we were live, stop it for now.
		self.wasLive = self.live
		if self.wasLive:
			self.live = False
			#end the thread. will start it later.
			self.streamThread.join()
			
# do it:
		if self.prevRadBut == "freqSweep":
			self.sweep()
		if self.prevRadBut == "whiteNoise":
			self.noise()
# done
		if self.wasLive:  #restart it.
			self.live = True
			self.streamThread = myStreamThread(self)
			self.streamThread.start()
		else:
			self.sourceCB.set_sensitive(True)
		self.liveView.set_sensitive(True)
		self.goButton.set_sensitive(True)
		self.setRadState(True)

		return

	def freqChanged(self, signal, filler):
		self.freq = self.freqAdjust.get_value()
		if self.playing:
			self.killPlay()
			self.play()

	def limitChanged(self, signal, true):
		startFreq = self.startFreqAdjust.get_value()
		endFreq = self.endFreqAdjust.get_value()
		
		if startFreq >= endFreq:				#not a possible operation
			self.endFreqAdjust.set_value(startFreq + 1)
			endFreq = self.endFreqAdjust.get_value()

		if self.freqAdjust.get_value() < startFreq:
			self.freqAdjust.set_value(startFreq)
		if self.freqAdjust.get_value() > endFreq:
			self.freqAdjust.set_value(endFreq)

		self.freqAdjust.set_lower(startFreq)
		self.freqAdjust.set_upper(endFreq)

	def radButtonChanged(self, widget, data=None):
		

		if data == None or data == self.prevRadBut:	#this method is called whenever any button is toggle
			return					#this makes it only execute when it's toggled to true
		if self.prevRadBut == "whiteNoise":
			self.saveNoiseTime = self.freqStepAdjustment.get_value()
		if self.prevRadBut == "freqSweep":
			self.saveSweepSteps = self.freqStepAdjustment.get_value()
		self.prevRadBut = data

		if data == "off":
#			self.freqStepLabel.set_text("Number of Frequency Steps")
#			self.freqStepAdjustment.set_lower(2)
#			self.freqStepAdjustment.set_upper(200)
#			self.freqStepAdjustment.set_value(40)
#			self.freqStepButton.set_digits(0)
#			self.freqStepButton.update()
			self.freqSen(True)
			self.comboBox.set_sensitive(True)
			self.goButton.set_sensitive(False)
			self.freqStepButton.set_sensitive(False)
			if self.playing:
				self.killPlay()
		elif data == "funcGen":
#			self.freqStepLabel.set_text("Number of Frequency Steps")
#			self.freqStepAdjustment.set_lower(2)
#			self.freqStepAdjustment.set_upper(200)
#			self.freqStepAdjustment.set_value(40)
#			self.freqStepButton.set_digits(0)
#			self.freqStepButton.update()
			#update frequency
#			self.freq1.update()
			self.freqSen(True)
			if self.playing:
				self.killPlay()
			self.play()
			#grey out "Go" button
			self.goButton.set_sensitive(False)
			self.freqStepButton.set_sensitive(False)
			self.comboBox.set_sensitive(True)
		elif data == "freqSweep":
			self.freqStepLabel.set_text("Number of Frequency Steps")
			self.freqStepAdjustment.set_lower(2)
			self.freqStepAdjustment.set_upper(200)
			self.freqStepAdjustment.set_value(self.saveSweepSteps)
			self.freqStepButton.set_digits(0)
			self.freqStepButton.update()
			if self.playing:
				self.killPlay()
			#set the wave type to sine
			self.comboBox.set_active(0)
			self.comboBox.set_sensitive(False)

			self.freq1.set_sensitive(False)
			self.freq2.set_sensitive(False)
			self.freq3.set_sensitive(True)
			self.freq4.set_sensitive(True)
			self.goButton.set_sensitive(True)
			self.freqStepButton.set_sensitive(True)			

		elif data == "whiteNoise":
			self.freqStepLabel.set_text("Duration(s)")
			self.freqStepAdjustment.set_lower(0.1)
			self.freqStepAdjustment.set_upper(20)
			self.freqStepAdjustment.set_value(self.saveNoiseTime)
			self.freqStepButton.set_digits(2)
			self.freqStepButton.update()
			if self.playing:
				self.killPlay()
			#set the wave type to white noise
			self.comboBox.set_active(3)
			self.comboBox.set_sensitive(False)

			self.freqSen(False)			#grey out all freq things, except freq steps
			self.goButton.set_sensitive(True)
			self.freqStepButton.set_sensitive(True)
			self.comboBox.set_sensitive(False)			

	def freqSen(self, status):
		self.freq1.set_sensitive(status)
		self.freq2.set_sensitive(status)
		self.freq3.set_sensitive(status)
		self.freq4.set_sensitive(status)
			
	def changed_sig_source(self, combobox):
		global mode
		if combobox.get_active() == 0:
			mode = 'arduino'
			self.streamWin.ax.set_ylim([-512,512])
		else:
			mode = 'soundcard'
			self.streamWin.ax.set_ylim([-20000,20000])



	def changed_cb(self, combobox):
		index = combobox.get_active()
			
		if index == 0:	#sine wave
			self.wave = "sine"
			if self.playing:
				self.killPlay()
				self.play()
		elif index == 1: #square wave
			self.wave = "square"
			if self.playing:
				self.killPlay()
				self.play()
		elif index == 2: #triangular wave
			self.wave = "triangle"
			if self.playing:
				self.killPlay()
				self.play()
		elif index == 3: #white noise
			self.wave = "noise"
			if self.playing:
				self.killPlay()
				self.play()
		return	
	

	def sweepWinClosed(self, widget, junk,sweepWin):
		if sweepWin.sweepFlag: # if its running, stop it.
			popup_msg("Sweep Aborted",widget)
			self.sweepWinAborted = True
			return True
		else:
#seems to help in memory usage
			del sweepWin
			gc.collect()
			return False

	def sweep(self):
		#if live view is open, stop that thread
		if not self.wasLive and mode == 'arduino':
			if not checkArduino(self.window):
				return True
			if not self.sendProgram(NUM_SAMPLES,True):
				return True
			#create the lockfile
			lFile  = open(LOCKFILE,"w")
			lFile.close()
			os.chmod(LOCKFILE,0666) 
				
		self.sweepFlag = True # true while we're sweeping
		self.sweepWinAborted = False #if sweep aborted by delete event
		#set radio buttons insensitive while sweeping

		#updating the start and end frequency spin button values - in case new values entered but not 'entered'
		self.freq3.update()
		self.freq4.update()
		
		#build the sweep window
		sweepWin = plotWindow("Frequency Sweep",tfbutton = False)
		sweepWin.sweepFlag = True
		base.sweepWin = sweepWin
		connection = sweepWin.window.connect("delete_event", self.sweepWinClosed,sweepWin)


		#reading the values
		startFreq = self.startFreqAdjust.get_value()
		endFreq = self.endFreqAdjust.get_value()
		n = self.freqStepButton.get_value_as_int()

		f = (endFreq - startFreq) / float(n-1)

 		sweepWin.fxvals=numpy.arange(n)*f+startFreq
		sweepWin.fyvals=numpy.zeros(n)
		sweepWin.view = 'freq'
		sweepWin.window.show_all()

		a=sweepWin.fig.gca()
		a.set_xlim([startFreq,endFreq])

# do a first play to wake up audio hardware
		self.freq = sweepWin.fxvals[0]			
		dataThread = getDataThread(self,str(AUDIO_DUR))
		dataThread.start()
		while not dataThread.doneFlag:
			gtk.main_iteration(block=True)
		dataThread.join()
		data = dataThread.data
###


		for i in range(n):	
			if self.sweepWinAborted:
				break

			self.freq = sweepWin.fxvals[i]

			dataThread = getDataThread(self,str(AUDIO_DUR))
			dataThread.start()
			while not dataThread.doneFlag:
				gtk.main_iteration(block=True)
			dataThread.join()
			data = dataThread.data

				
#			self.play()
#			data = self.get_data(AUDIO_DUR)
#			self.killPlay()
			
			rms = numpy.sqrt(numpy.sum(data*data)/data.size)
			sweepWin.fyvals[i] = rms

			sweepWin.ax.cla()
			sweepWin.ax.set_xlabel("Frequency (Hz)")
			sweepWin.ax.set_ylabel("RMS")
			sweepWin.ax.plot(sweepWin.fxvals,sweepWin.fyvals)
			sweepWin.ax.plot(sweepWin.fxvals,sweepWin.fyvals, '.')
			sweepWin.window.show_all()

			sweepWin.canvas.draw_idle()
			if self.wasLive:				#then we're streaming
				self.streamWin.tyvals = data
				self.streamWin.fyvals = numpy.abs(numpy.fft.rfft(data)/data.size)
				self.streamWin.updatePlot()

			while gtk.events_pending():		#makes sure the GUI updates
	            		gtk.main_iteration()
		if not self.wasLive and mode == 'arduino':
			self.sendProgram(0,False)
			self.runLast()
			remove_lockfile()

		sweepWin.sweepFlag = False
		self.freq = self.freqAdjust.get_value()

	def noiseWinClosed(self, widget, junk,noiseWin):
#seems to help in memory usage
		del noiseWin
		gc.collect()
		return False


	def noise(self):

		label = gtk.Label("Doing noise measurement, please wait")
		idialog = gtk.Dialog("Noise measurement",self.window)
		idialog.vbox.pack_start(label)

#		abortButton = gtk.Button("Abort")
#		abortButton.connect_object("clicked", self.abort, self.abortFlag)
#		idualog.vbox.pack_start(abortButton)
		idialog.show_all()


		while gtk.events_pending():		#to actually show the dialog.
			gtk.main_iteration()
		time.sleep(.005) #seems to be necessary to see the whole thing...
		while gtk.events_pending():		#to actually show the dialog.
			gtk.main_iteration()


		
		nWin = plotWindow("Noise Spectrum",tfbutton=True)

#this appears to prevent some of nWin's variables from being inexplicably garbage collected.
		global base
		base.nWin = nWin
		nWin.window.connect("delete_event", self.noiseWinClosed,nWin)

		duration = self.freqStepButton.get_value()
		if mode == "arduino" and not self.wasLive:
			if not checkArduino(self.window):
				return True
			#create the lockfile
		if mode == "arduino":
			rate = 1/float(TIME_STEP)
			if not self.sendProgram(int(duration/TIME_STEP),True):
				return True
			if not self.wasLive:
				lFile  = open(LOCKFILE,"w")
				lFile.close()
				os.chmod(LOCKFILE,0666) 
		else:
			rate = AUDIO_FREQ
		
		dataThread = getDataThread(self,str(duration))
		dataThread.start()
		while not dataThread.doneFlag:
			gtk.main_iteration(block=True)

		dataThread.join()
		nWin.tyvals = dataThread.data

		nWin.calcXvals(nWin.tyvals.size,rate)

		#do the fourier transform:
		nWin.fyvals = numpy.abs(numpy.fft.rfft(nWin.tyvals)/nWin.txvals.size)


		#plot the magnitude of the FT'd data
		a=nWin.fig.gca()
		nWin.view = 'freq'
		nWin.tfbutton.set_active(True)
		nWin.line = Line2D(nWin.fxvals,nWin.fyvals)
		min = numpy.amin(nWin.fxvals)
		max = numpy.amax(nWin.fxvals)
		nWin.ax.set_xlim(calc_lims(min,max))
		min = numpy.amin(nWin.fyvals)
		max = numpy.amax(nWin.fyvals)
		nWin.ax.set_ylim(calc_lims(min,max))
		nWin.ax.add_line(nWin.line)
		nWin.ax.set_xlabel("Frequency (Hz)")
		nWin.ax.set_ylabel("Amplitude")

		nWin.window.show_all()

		if mode == "arduino" and self.wasLive == True:
			self.sendProgram(NUM_SAMPLES,True)
		if mode == "arduino" and not self.wasLive:
			self.sendProgram(0,False)
			self.runLast()
			remove_lockfile()
		idialog.destroy()
		return

	def play(self):
		#note:frequency is in hertz
		pid = os.fork()
		if pid == 0:
			#this will play for 60 hours, or until killed.
# gain used to be -3
			os.system('play -q -n synth 216000 '+ self.wave +' '+str(self.freq)+' gain -12 < /dev/null')
			return
		self.pid = pid
		time.sleep(AUDIO_PLAY_DELAY)
		self.playing = True
		return

	def killPlay(self):
		if not self.pid:
			return
		try:
			os.kill(self.pid, signal.SIGKILL)
			os.system("killall -9 play")
			os.waitpid(self.pid, 0)
			self.playing = None
		except:
			pass


	def main(self):	       
		gtk.gdk.threads_enter()
		gtk.main() 
		gtk.gdk.threads_leave()

#print __name__
if __name__ == "__main__":
	base = topWin()
	base.main()

