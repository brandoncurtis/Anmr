import numpy
import sys
import gtk
import serial
import time
import os.path
from matplotlib.backends.backend_gtk import NavigationToolbar2GTK as NavigationToolbar2GTK
from matplotlib.backends.backend_gtkagg import NavigationToolbar2GTKAgg as NavigationToolbar2GTKAgg

#configuration definitions:
#these will force us to guess - if ttyACM0 exists, we'll assume uno
#if not, we'll try ttyUSB0 and assume deumillanove (atmega328) 
ARDUINO_DEV = 'auto'
ARDUINO_BOARD = 'auto'

#To force DEV and BOARD settings:  
#ARDUINO_DEV is the node in /dev
#ARDUINO_BOARD is used by scons -> avrdude to program it.
#it sets the protocol.

###### for Deumillanove
#ARDUINO_DEV = 'ttyUSB0'
#ARDUINO_BOARD = 'atmega328'

###### for Uno:
#ARDUINO_DEV = 'ttyACM0'
#ARDUINO_BOARD = 'uno'

ARDUINO_CODE = '/usr/local/share/Anmr/arduinoCode/'
IMAGE_VIEWER = "/usr/bin/eog -n"
#where runProgram and compAndDown live:
C_PROG_BIN_PATH = '/usr/local/share/Anmr/Cdrivers/'
#by default, we keep data here:
DATA_DIR = "~/anmr-data/"

#pulse programs:
PROG_DIR = '/usr/local/share/Anmr/PulsePrograms/'
#pulse program header file:
HEADER_NAME = 'defaults.include'
SOCAT='/usr/bin/socat'

TEMP_DIR="/tmp/Anmr"
TEMP_PROG_NAME=TEMP_DIR+"/anmr-prog.txt"
LOCKFILE=TEMP_DIR+"/anmr-lockfile"

IDENTIFIER = 'ANMR v0.8, Ready\r\n'

# the linux cdc-acm module needed for the arduino uno has a nasty habit of resetting the
# uno on every open of the file descriptor. To avoid it, we call socat to
# pipe the arduino to a pty, and then we talk to the pty.
SERIAL_PTY=TEMP_DIR+"/anmr-pty"

#104 us is the time per point we get from the arduino.
TIME_STEP=.000104

#these used internally, so that subsequent calls will auto-detect if board-type is changed.
_ARDUINO_DEV = None
_ARDUINO_BOARD = None

def checkArduino(window = None):
# check to make sure /tmp/Anmr exists
    if not os.path.isdir(TEMP_DIR): # if our directory doesn't exist, create it.
        try:
            os.mkdir(TEMP_DIR)
            os.chmod(TEMP_DIR,0777) 
        except:
            popup_msg("problem creating directory: "+TEMP_DIR)
            return False


    idialog = None
#look for the lockfile:
    try:
        stat = os.stat(LOCKFILE)
        lockFile = True
    except:
        lockFile = False
        pass

#look for the pty:
    try:
        stat = os.stat(SERIAL_PTY)
        ptyFile = True
    except:
        ptyFile = False
        pass

    print 'lockFile: ',lockFile,' ptyFile: ',ptyFile

    if lockFile:
        if ptyFile:
            popup_msg("A lockfile exists indicating the arduino is in use.\nIf you are certain it is not being accessed by another instance of FuncGen or Anmr,\nunplug the arduino, plug it in again and then wait 10 s before trying again.\n")
            return
        else: #if the lockfile exists but the pty doesn't, wipe out the lockfile
            print 'wiping out ',LOCKFILE
            os.remove(LOCKFILE)

# so at this point there should be no lockfile, but socat may or may not be running.

    if not ptyFile: #socat is not running

        label = gtk.Label("Hardware initialization...")
        label.show()
        idialog = gtk.Dialog("Initializing Hardware",window)
        idialog.vbox.pack_start(label)
        idialog.show_all()
        
        while gtk.events_pending():		#to actually show the dialog.
            gtk.main_iteration()
        time.sleep(.05) #seems to be necessary to see the whole thing...
        while gtk.events_pending():		#to actually show the dialog.
            gtk.main_iteration()

        #test the bare arduino, download program if necessary, and start socat
        global _ARDUINO_DEV
        global _ARDUINO_BOARD
#figure out device and path
        if ARDUINO_DEV == "auto": # if ARDUINO_DEV was set above, then don't try to auto-detect
            found = False
            try:
                stat = os.stat("/dev/ttyACM0")
                _ARDUINO_DEV="ttyACM0"
                found = True
            except: #didn't find it.
                pass
            if not found:
                try:
                    stat = os.stat("/dev/ttyUSB0")
                    _ARDUINO_DEV="ttyUSB0"
                except:
                    idialog.destroy()
                    popup_msg("Couldn't auto-detect the arduino.\nIs there a board connected?")
                    return False
        else:
            _ARDUINO_DEV = ARDUINO_DEV

        if ARDUINO_BOARD == "auto":
            if _ARDUINO_DEV == "ttyACM0":
                _ARDUINO_BOARD = 'uno'
            elif _ARDUINO_DEV == "ttyUSB0":
                _ARDUINO_BOARD = 'atmega328'
            else:
                idialog.destroy()
                popup_msg("Couldn't auto-guess the arduino board type.")
                return False
        else:
            _ARDUINO_BOARD = ARDUINO_BOARD

        ARDUINO_PORT = '/dev/' + _ARDUINO_DEV

        result = testArduino(ARDUINO_PORT)
        if result == -1:
            popup_msg("Arduino device: "+ ARDUINO_PORT+" couldn't be opened.\nIs the arduino connected?\nIs the correct path specified?\nPermissions problem?")
            idialog.destroy()
            return False
        if result == 0:
        #ask the user if we should download the server:
            dialog = gtk.Dialog("Attention!",window)
            label = gtk.Label("Arduino does not hold server. Upload server?")
            dialog.vbox.pack_start(label)
            dialog.add_buttons("No", gtk.RESPONSE_NO, "Yes", gtk.RESPONSE_YES)
            dialog.show_all()
            response = dialog.run()	# -8 is yes, and -9 is no
            dialog.destroy()
            if response == gtk.RESPONSE_YES:
                try:
                    os.chdir(ARDUINO_CODE)
                    os.system("scons ARDUINO_PORT="+ ARDUINO_PORT + " ARDUINO_BOARD="+ _ARDUINO_BOARD+" upload")
                    result = testArduino(ARDUINO_PORT)
                    if result != 1:
                        popup_msg("Tried to download server,\nbut the arduino isn't responding correctly.")
                        idialog.destroy()
                        return False
                except :
                    idialog.destroy()
                    return False
            else:
                idialog.destroy()
                return False

#so to be here, the arduino should now be running the server.
#start socat
        pid = os.fork()
        if pid == 0:
            os.execl(SOCAT,SOCAT,'pty,raw,echo=0,link='+SERIAL_PTY+',mode=666',ARDUINO_PORT+',raw,echo=0,b1000000')

#           os.execl(SOCAT,SOCAT,'pty,raw,echo=0,link='+SERIAL_PTY,ARDUINO_PORT+',raw,echo=0,b1000000,clocal,cs8,ixon=0,icrnl=0,icanon=0,opost=0,isig=0')
#           os.execl(SOCAT,SOCAT,'pty,raw,echo=0,link='+SERIAL_PTY+',clocal,b1000000,cs8,ixon=0,icrnl=0,icanon=0,opost=0,isig=0',ARDUINO_PORT+',raw,echo=0,b1000000,clocal,cs8,ixon=0,icrnl=0,icanon=0,opost=0,isig=0')
        # that call never returns

        time.sleep(2) # wait two seconds for bootloader
 
######

#now check the pty
    result = testArduino(SERIAL_PTY)
    print 'checking ',SERIAL_PTY,' result:', result
    if idialog != None:
        idialog.destroy()
    if result == 1: #all is well, go home
        return 1

    if result == 0: #the pty is running but the sever isn't responding as expected
        popup_msg("The arduino did not respond as expected.\nTry again. If it still doesn't work, unplug the arduino, plug it back in, then wait 10s before trying again")
    if result == -1:
        popup_msg("Could not access the arduino.\n")

    return False

           
def testArduino(path):
#don't call this, it's for checkArduino to use.
#returns 
# 1 if all is well, 
# 0 if the port exists but isn't running our server
# -1 if the port doesn't exist, or we don't have permission to open it.

    print 'in testArduino for port: ',path
    try:
        print 'trying to open port'
        ser = serial.Serial(path, 1000000, timeout = 2)
    except:
        return -1
# ok, port exists and is open
    if path != SERIAL_PTY:
        time.sleep(2) #if its the hardware port, wait while the bootloader runs.
    # write query:
    print 'opened port, writing QUERY'
    ser.write(chr(14)) #14 is QUERY
    for i in range(5):
	line = ser.readline()   # read a '\n' terminated line
        ser.close()
        print 'got ',line
        if line == IDENTIFIER:
            return 1
	return 0 # didn't get correct response from server.


class popup_msg:

	def __init__ (self,message,window = None):
		dialog = gtk.Dialog("Anmr",window)
		label = gtk.Label(message)
		dialog.vbox.pack_start(label)
		button = gtk.Button("Okay")
		dialog.vbox.pack_end(button)
		button.connect_object("clicked", self.killDialog, dialog)
		dialog.show_all()
		
	def killDialog(self, toBeKilled):
		toBeKilled.destroy()
		return


def calc_lims(min,max):
	spread = (max-min)*1.1/2
        if spread == 0:
            spread = 0.1
	mid = (max+min) /2.
	max = mid+spread
	min = mid-spread
	return (min,max)


def readAFile(filename):
#	print 'in readFile with name:', filename
# if points has some value, we'll truncate to that many, or pad with zeros.
#unless we got  no points
	try:
            inFile = open(filename)
            lines = inFile.readlines()
            if lines == []:
                inFile.close()
                return [-1,-1]
            if lines[0][0] == '#':
                numScans = int(lines[0][1:])
                start = 1
            else:
                numScans = 0
                start = 0
            tnums = numpy.array(lines[start:])
            inFile.close()
            return [tnums.astype(int),numScans]
	except:
           
            inFile.close()
            return [-1,-1]



class MyToolbar(NavigationToolbar2GTKAgg):
#idea borrowed from: http://dalelane.co.uk/blog/?p=778
# but redone a bit differently.

# we inhereit the navigation toolbar, but redefine the toolitems

    # list of toolitems to add to the toolbar, format is:
    # text, tooltip_text, image_file, callback(str)
    toolitems = (
        ('Home', 'Reset original view', 'home.png', 'home'),
        ('Back', 'Back to  previous view','back.png', 'back'),
        ('Forward', 'Forward to next view','forward.png', 'forward'),
        ('Pan', 'Pan axes with left mouse, zoom with right', 'move.png','pan'),
        ('Zoom', 'Zoom to rectangle','zoom_to_rect.png', 'zoom'),
        (None, None, None, None),
#        ('Subplots', 'Configure subplots','subplots.png', 'configure_subplots'),
        ('Save', 'Save the figure','filesave.png', 'save_figure'),
        )

