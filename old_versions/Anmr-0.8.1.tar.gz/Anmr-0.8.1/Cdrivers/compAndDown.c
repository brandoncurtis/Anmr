/*
	File name: compAndDown.c
	Programmer: Daniel Hon Kit Chong and Carl Michal


arduino uno has a problem.  Serial port resets when opened no matter what I do...
looks like this is hardcoded into the cdc-acm driver.

try this:

socat   PTY:raw,echo=0,link=/tmp/com1,clocal,b1000000,cs8,ixon=0,icrnl=0,icanon=0,opost=0,isig=0 /dev/ttyACM0,raw,echo=0,b2000000,clocal,cs8,ixon=0,icrnl=0,icanon=0,opost=0,isig=0

*/

#include <termios.h>
#include <fcntl.h>
#include <unistd.h>
#include "definitions.h"
#include <stdio.h>
#include <stdlib.h>
#include "funcProto.h"
#include <string.h>
#include <sys/ioctl.h>

#define MAX_VARS 200
#define VAR_LENGTH 30

char varNames[MAX_VARS][VAR_LENGTH];
unsigned int varVals[MAX_VARS];
int numVariables =0;
unsigned int totalReadings = 0;
	
void readStr(int portID, char* output, int size)
{
	int i;
	char temp;
	//	printf("in readStr\n");
	for (i=0; i<size ; i++)
	{
		read(portID, &temp,1);
		if (temp == '\n') {
			output[i] = 0;
			printf("%s\n", output);
			return;
		}
		output[i] = temp;
	}
	output[size-1] = 0;
	//	printf("readStr2: %s\n", output);
}


int determineCommand(char* line)
{
	char temp[300];
	char tempInt1[300]; 
	char  tempInt2[300];
	int i,rval,found;

//	sscanf(line, "%[^' '] %s %s", temp, tempInt1, tempInt2);
	rval = sscanf(line, "%s %s %s", temp, tempInt1, tempInt2);
	if (rval < 1) return 0; // whitespace
	//if (rval < 2) return -1; // syntax error if no arguments
	//unapplicable: END_LOOP has no arguments
	if (strncmp( "DELAY_IN_CLOCKS", temp, 15) == 0)
		return DELAY_IN_CLOCKS;
	else if (strncmp("DELAY_IN_MS", temp, 11) == 0)
		return DELAY_IN_MS;	
	else if (strncmp("CHANGE_PIN", temp, 10) == 0)
		return CHANGE_PIN;
	else if (strncmp("WAIT_FOR_PIN", temp, 12) == 0)
		return WAIT_FOR_PIN;
	else if (strncmp("SET_PULSE_PINS", temp, 14) == 0)
		return SET_PULSE_PINS;
	else if (strncmp("PULSE", temp, 5) == 0)
		return PULSE;
	else if (strncmp("READ_DATA", temp, 9) == 0)
	{	
		if (rval <3 ) return -1;/*
		if (tempInt2[0] == '%'){ 		//then a variable
			found = 0;
			for (i=0;i<numVariables;i++){
				if ( strncmp ( (tempInt2 + 1), varNames[i], strlen(varNames[i]) ) == 0)
				{
					*pTotalReadings += (unsigned int) varVals[i];
					found = 1;
				}
			}
			if (!found)
				return -2;	//unresolved variable
		}
		else{					//is not a variable
			*pTotalReadings += (unsigned int) strtol (tempInt2, NULL, 10);
		}*/
		return READ_DATA;
	}
	else if (strncmp("SET_FREQ", temp, 8) == 0)
		return SET_FREQ;
	else if (strncmp("LOOP", temp, 4) == 0)
		return LOOP;
	else if (strncmp("END_LOOP", temp, 8) == 0)
		return END_LOOP;
	else if (strncmp("SYNC", temp, 4) == 0)
		return SYNC;
	else
	{
		return -1;
	}
}

int getArgs(char* line, unsigned int* arg1, unsigned int* arg2, unsigned int* arg3,unsigned int *arg4)
/*
 *This function gets the arguments from an instruction according to the syntax:
 *<instruction> <argument1> <argument2> <argument3> <argument4>
 *given the line, the pointers to the variables. 
 *If the command has fewer arguments, the NULL pointer is passed for those that don't exist.

 we return -9 if we couldn't resolve a variable, -11 if we didn't find enough values on the command line.

 Boy is this ugly. So much duplication...

 */
{
	char discard[300];
	char temp1[300];
	char temp2[300];
	char temp3[300];
	char temp4[300];
	int i, found,j;
	j = sscanf(line, "%s %s %s %s %s", discard, temp1, temp2, temp3, temp4);
	if (j < 2) return -11;
	if (temp1[0] == '%'){
	  found = 0;
	  for ( i = 0 ; i < numVariables ; i++ ){
	    if ( strncmp ( (temp1 + 1), varNames[i], strlen(varNames[i]) ) == 0)
	      {
		*arg1 = (unsigned int) varVals[i];
		found = 1;
	      }
	  }
	  if (!found)
	    {
	      printf("temp: %s\n", temp1+1);
	      return -9;
	    }
	}
	else
	  *arg1 = (unsigned int) strtol (temp1, NULL, 10);
	if (arg2 != NULL){	//two arguments
	  if (j < 3) return -11;
	  if (temp2[0] == '%'){
	    found = 0;
	    for (i=0;i<numVariables;i++){
	      if ( strncmp ( (temp2 + 1), varNames[i], strlen(varNames[i]) )== 0)
		{
		  *arg2 = (unsigned int) varVals[i];
		  found = 1;
		}
	    }
	    if (!found)
	      {
		printf("temp: %s\n", temp2+1);
		return -9;
	      }
	  }
	  else
	    *arg2 = (unsigned int) strtol (temp2, NULL, 10);
	}
	if (arg3 != NULL){	//three arguments
	  if (j < 4) return -11;
	  if (temp3[0] == '%'){
	    found = 0;
	    for (i=0;i<numVariables;i++){
	      if ( strncmp ( (temp3 + 1), varNames[i], strlen(varNames[i]) )== 0)
		{
		  *arg3 = (unsigned int) varVals[i];
		  found = 1;
		}
	    }
	    if (!found)
	      {
		printf("temp: %s\n", temp3+1);
		return -9;
	      }
	  }
	  else
	    *arg3 = (unsigned int) strtol (temp3, NULL, 10);
	}
	if (arg4 != NULL){	//four arguments
	  if (j<5) return -11;
	  if (temp4[0] == '%'){
	    found = 0;
	    for (i=0;i<numVariables;i++){
	      if ( strncmp ( (temp4 + 1), varNames[i], strlen(varNames[i]) )== 0)
		{
		  *arg4 = (unsigned int) varVals[i];
		  found = 1;
		}
	    }
	    if (!found)
	      {
		printf("temp: %s\n", temp4+1);
		return -9;
	      }
	  }
	  else
	    *arg4 = (unsigned int) strtol (temp4, NULL, 10);
	}
	return 0;
}

int readCommands (int portID, char* fileName, char* charBuffer, long* checksum1, long* checksum2)
{
	FILE * inFile;
	int i, j;
	int numBytes = 3;
	int numReadings = -1;
	int freqSet = 0;
	int pinsSet = 0;
	char line[300];
	char discard[300];
	char temp1[300];
	char temp2[300];	
	int found, loopNum;
	int loopStarted = 0;
	int nullLoop = 0;
	
	int lineNum = 1;

	int position = 0;
	int rv;

	inFile = fopen(fileName, "r");
	fgets(line,300,inFile);
	sscanf(line, "%s", discard);
	if (strncmp("PULSE_PROGRAM", discard, 13) != 0) return -5;	//does not have the identifier first line

	char sbuff[50];			

	while (fgets(line,300,inFile))
	{
		//printf("%s \nnullLoop = %d\n", line, nullLoop);
		if (line[0] == '%')		//then this is a variable definition
		{
			found = 0;
			sscanf(line+1, "%s = %s", temp1, temp2);
			for (i=0;i<numVariables;i++)	//this replaces any value
			{
				if ( strncmp ( temp1, varNames[i], strlen(varNames[i]) ) == 0)
				{
					varVals[i] = strtol(temp2, NULL, 10);
					found = 1;
				}
			}
			if (!found)
			{
				sscanf(line+1, "%s = %d", varNames[numVariables], &varVals[numVariables]);
				numVariables++;
			}
		}
		else if ( line[0] != '#')	//then this line is not a comment
		{
			switch (determineCommand(line))
			{
				case DELAY_IN_CLOCKS:	
				{	
					unsigned int clockCycles;
					if (nullLoop) break;
					rv = getArgs(line, &clockCycles, NULL, NULL, NULL);
					if ( rv != 0)
						return rv;
					if (clockCycles > 0)
					{
						if (clockCycles <= 104){	
							clockCycles = 105;
						}
						delayInClocks(charBuffer, &position, clockCycles);
					}
				}
				break;
				case DELAY_IN_MS:
				{	
					unsigned int ms;
					if (nullLoop) break;
					rv = getArgs(line, &ms, NULL, NULL, NULL);
					if ( rv != 0)
						return rv;
					if (ms > 0)
						delayInMs(charBuffer, &position, ms);
				}
				break;
				case CHANGE_PIN:
				{	
					unsigned int pinNum, state;
					if (nullLoop) break;
					rv = getArgs(line, &pinNum, &state, NULL, NULL);
					if ( rv != 0)
						return rv;
					changePin(charBuffer, &position, pinNum, state);
				}
				break;
				case WAIT_FOR_PIN:
				{	
					unsigned int pinNum, edge;
					if (nullLoop) break;
					rv = getArgs(line, &pinNum, &edge, NULL, NULL);
					if ( rv != 0)
						return rv;
					waitForPin(charBuffer, &position, pinNum, edge);
				}
				break;
				case PULSE:	//note: check if freq has been set
				{	
				  unsigned int phase, numHalfCycles,phaseInc,phaseMod;
					if (nullLoop) break;
					rv = getArgs(line, &phase,&phaseInc,&phaseMod,&numHalfCycles);
					if ( rv != 0)
						return rv;
					if (freqSet == 0 || pinsSet == 0 )
					  return -3;
					if (phaseMod == 0) phaseMod = 1;
					pulse(charBuffer, &position, phase, phaseInc,phaseMod,numHalfCycles);
				}
				break;
				case READ_DATA:
				{	
				  unsigned int phase, phaseInc,phaseMod,localNumReadings;
					if (nullLoop) break;
					rv = getArgs(line, &phase,&phaseInc,&phaseMod,&localNumReadings);
					if ( rv != 0)
						return rv;
					if (phaseInc > 0 && freqSet == 0)
					  return -3;
					if (phaseMod == 0) phaseMod = 1;
					readData(charBuffer, &position, phase, phaseInc,phaseMod,localNumReadings);
					if (!loopStarted)	//then we're not in a loop
						totalReadings += localNumReadings;
					else			//then we are
						totalReadings += localNumReadings * loopNum;
				}
				break;
				case SET_FREQ:
				{	
					unsigned int freq;
					if (nullLoop) break;
					rv = getArgs(line, &freq, NULL,NULL,NULL);
					if (rv != 0)
						return rv;
					setFreq(charBuffer, &position, freq);
					freqSet = 1;
				}
				break;
				case SET_PULSE_PINS:
				{	
				        unsigned int pin1,pin2;
					if (nullLoop) break;
					rv = getArgs(line, &pin1, &pin2,NULL,NULL);
					if ( rv != 0)
						return rv;
					setPulsePins(charBuffer, &position, pin1,pin2);
					pinsSet = 1;
				}
				break;
				case LOOP:	//note: nested loops not allowed
				{	
					if (loopStarted)
						return -10;
					loopStarted = 1;

					unsigned int loops;
					rv = getArgs(line, &loops, NULL,NULL,NULL);
					if ( rv != 0)
						return rv;
					if (loops == 0)
					{
					  nullLoop = 1; // set to one if user requested a loop run 0 times
						break;
					}
					loopNum = loops;
					loop(charBuffer, &position, loops);
				}
				break;
				case END_LOOP:
				{	
					if (!loopStarted)
						return -10;
					endLoop(charBuffer, &position);
					loopStarted = 0;
					nullLoop = 0;
				}
				break;
				case SYNC:
				{
					if (nullLoop) break;
					ardSync(charBuffer, &position);
				}
				break;
				case 0: break;
				default:
					return -6;
				case -2: return -9;
			}
		}
	}
	if (loopStarted)	//ensure all loops are closed
		return -10;
       	endOfProgram(charBuffer, &position, numBytes+3);	// writes into the buffer


	tcflush(portID,TCIOFLUSH);

	printf("about to look for ready\n");
	sbuff[0] = QUERY;
	write(portID,sbuff,1);
	readStr(portID, sbuff, 50);
	if (strncmp("ANMR v0.8, Ready", sbuff,16) != 0){
	  printf("Didn't find ready signal!\n");
	  return -7;
	}
	printf("Got Ready signal\n");
	numBytes = position;


	numBytes = position;
	//	printf("calling startOfProgram \n");
	startOfProgram(portID, numBytes, (unsigned int) totalReadings); // writes directly to the device
	//	printf("done calling startOfProgram \n");

	

	i=0;
	printf("Waiting for confirm of program start\n");
	do{
		readStr(portID,sbuff,50);
		if(strncmp(sbuff,"Malloc failed!",14) == 0) return -4;
		i+=1;
		if (i == 100) return -4;
	} while(strncmp(sbuff,"Malloc successful",17) != 0);
	printf("starting to download program of %i bytes\n",position);
	//begin sending
	char tempVal = '\0';
	*checksum1 = 0;
	*checksum2 = 0;
	for (i=0;i<position;i++){
		tempVal = ( (unsigned) charBuffer[i] )& 0xFF;
		write(portID,&tempVal,1);
		usleep(120);
		*checksum1 += (unsigned) (i+1)*( ((unsigned) charBuffer[i] )& 0xFF);
		*checksum2 += (unsigned) (i+2)*( ((unsigned) charBuffer[i] )& 0xFF);
	}
	return 1;
}


int main (int argc, char *argv[])
/*	
	return value interpretations:
	 1 = no error
	-1 = Incorrect number of arguments
	-2 = Cannot open port
	-3 = freq not set before pulse/read
	-4 = Malloc failed
	-5 = loaded instruction set doesn't have identifier first line
	-6 = invalid instruction
	-7 = Didn't get ready signal
	-8 = checksum error
	-9 = unresolved variable
	-10 = loop disagreement
	-11 = wrong number of arguments in pulse program command
*/


{
  int eo;
  if (argc != 3){
    printf("Wrong number of arguments. Terminating program");
    return -1;
  }
  
  char portName[300];
  //  sscanf (argv[1], "%s", portName);
  strcpy(portName,argv[1]);

  char fileName[300];
  //sscanf (argv[2], "%s", fileName);
  strcpy(fileName,argv[2]);

  long ardChecksum1, ardChecksum2, checksum1, checksum2;
  int fd0;
  int k,j;
  char charBuffer[16000];
  int i;
  for (i=0;i<16000;i++){
    charBuffer[i] = 0;
  }
  struct termios myterm;
  
  fd0 = open(portName, O_RDWR|O_NOCTTY);
  if (fd0 < 0){
    printf("couldn't open port\n");
    return -1;
  }
  
  tcgetattr( fd0, &myterm );
  
  myterm.c_iflag = 0;
  myterm.c_oflag = CR0 ;
  myterm.c_cflag =  CS8 | CLOCAL |CREAD | B1000000;
  
  myterm.c_cc[VMIN]=1; 
  myterm.c_cc[VTIME]=0; 
  
  j= cfsetospeed( &myterm, B1000000 ); 
  if (j<0) perror("error setting speed");
  
  j= cfsetispeed( &myterm, B1000000 ); 
  if (j!=0) perror("error setting speed");
  
  j=tcsetattr( fd0, TCSANOW, &myterm );
  if (j<0) perror("error setting attributes");
  tcflush(fd0,TCIOFLUSH);
  
  int retVal = readCommands(fd0, fileName, charBuffer, &checksum1, &checksum2);
  if (retVal != 1){
    printf("retVal: %d\n", retVal);
    return retVal;
  }
  
  
  checksum1 = (long)checksum1;
  checksum2 = (long)checksum2;
  char sbuff[50];	
  
  readStr(fd0, sbuff, 50);
  
  //	ardChecksum1 = strtol(sbuff, NULL, 10);
  eo = sscanf(sbuff,"%li",&ardChecksum1);
  if (strncmp(sbuff,"Timed out",9) == 0 || eo != 1){
    printf("didn't get chksum\n");
    return -8;
  }
  
  readStr(fd0, sbuff, 50);
  //	ardChecksum2 = strtol(sbuff, NULL, 10);
  eo = sscanf(sbuff,"%li",&ardChecksum2);
  if (strncmp(sbuff,"Timed out",9) == 0){
    printf("didn't get chksum\n");
    return -8;
  }
  
  close(fd0);
  printf("almost done\n");
  
  printf("%ld %ld\n%ld %ld\n", checksum1, ardChecksum1, checksum2, ardChecksum2); 
  
  if ( (checksum1 != ardChecksum1) || (checksum2 != ardChecksum2) ){
    printf("Checksum MISMATCH\n");	
    return -8;
  }
  else printf("Checksums OK\n");
  return retVal;
}


