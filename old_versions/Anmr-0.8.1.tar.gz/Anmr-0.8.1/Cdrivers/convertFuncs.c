#include <unistd.h>
#include <stdio.h>
#include "definitions.h"

#define BASE 0xFF


void startOfProgram(int portID, unsigned int bytes, unsigned int numReadings)
{
  int eo;
  char outb;
	outb= START_OF_PROGRAM;			//instruction char
	eo = write(portID,&outb,1);

	outb = (char) BASE & bytes;
	eo += write(portID,&outb,1);
	outb = (char) BASE & (bytes >> 8);
	eo += write(portID,&outb,1);

	outb = (char) BASE & numReadings;
	eo += write(portID,&outb,1);
	outb = (char) BASE & (numReadings >> 8);
	eo += write(portID,&outb,1);
	outb = (char) BASE & (numReadings >> 16);
	eo += write(portID,&outb,1);
	outb = (char) BASE & (numReadings >> 24);
	eo += write(portID,&outb,1);
	
}

void go(unsigned int portID)
{
	char outb = GO;
	write(portID,&outb,1);				//instruction char
}

void endOfProgram(char* charBuffer, int* position)
{
	charBuffer[*position] = END_OF_PROGRAM;
	*position += 1;

}

void delayInClocks(char* charBuffer ,int* position, unsigned int clockCycles)
{	
	charBuffer[*position] = DELAY_IN_CLOCKS;
	*position += 1;

	
	charBuffer[*position] = (char) BASE & clockCycles;
	*position += 1;					//total number of clock cycles (4 chars)
	
	charBuffer[*position] = (char) BASE & (clockCycles >> 8);
	*position += 1;	

	charBuffer[*position] = (char) BASE & (clockCycles >> 16);
	*position += 1;	

	charBuffer[*position] = (char) BASE & (clockCycles >> 24);;
	*position += 1;	
}

void delayInMs(char* charBuffer ,int* position, unsigned int ms)
{
				//instruction char
	charBuffer[*position] =  DELAY_IN_MS;
	*position += 1;


	charBuffer[*position] = (char) BASE & ms;
	*position += 1;					//number of milliseconds worth of delay (2 chars)
	charBuffer[*position] = (char) BASE & (ms >> 8);

	*position += 1;
}

void changePin(char* charBuffer ,int* position, unsigned int pinNum, unsigned int state)
{

	  				//instruction char
	charBuffer[*position] = CHANGE_PIN;
	*position += 1;

	 		//pin number
	charBuffer[*position] = (char) BASE & pinNum;
	*position += 1;

	 			//state (non-zero = high, zero = low)
	charBuffer[*position] = (char) BASE & state;
	*position += 1;
}

void waitForPin(char* charBuffer ,int* position, unsigned int pinNum, unsigned int edge)
{
	  			//instruction char
	charBuffer[*position] = WAIT_FOR_PIN;
	*position += 1;

	 		//pin number
	charBuffer[*position] = (char) BASE & pinNum;
	*position += 1;

	 			//edge (0 = any, 1 = rising, >1 = falling)
	charBuffer[*position] = (char) BASE & edge;
	*position += 1;
}


void pulse(char* charBuffer ,int* position, unsigned int phase, unsigned int phaseInc,unsigned int phaseMod,unsigned int numHalfPeriods)
{
			//instruction char
	charBuffer[*position] = PULSE;
	*position += 1;

	 	//phase char
	charBuffer[*position] = (char) BASE & phase;	
	*position += 1;
	charBuffer[*position] = (char) BASE & (phase >> 8);	
	*position += 1;

	charBuffer[*position] = (char) BASE & phaseInc;	
	*position += 1;
	charBuffer[*position] = (char) BASE & (phaseInc >> 8);	
	*position += 1;

	charBuffer[*position] = (char) BASE & phaseMod;	
	*position += 1;

	 
	charBuffer[*position] = (char) BASE & numHalfPeriods;
	*position += 1;					//number of half periods (2 chars)
	charBuffer[*position] = (char) BASE & (numHalfPeriods >> 8);
	*position += 1;			
}

void readData(char* charBuffer ,int* position, unsigned int phase, unsigned int phaseInc, unsigned int phaseMod,unsigned int numReadings)
{ 				
	charBuffer[*position] = READ_DATA;
	*position += 1;	

	charBuffer[*position] = (char) BASE & phase;	
	*position += 1;
	charBuffer[*position] = (char) BASE & (phase >> 8);	
	*position += 1;

	charBuffer[*position] = (char) BASE & phaseInc;	
	*position += 1;
	charBuffer[*position] = (char) BASE & (phaseInc >> 8);	
	*position += 1;

	charBuffer[*position] = (char) BASE & phaseMod;	
	*position += 1;

	charBuffer[*position] = (char) BASE & numReadings;
	*position += 1;					//number of readings (4 chars)
	charBuffer[*position] = (char) BASE & (numReadings >> 8);
	*position += 1;	
	charBuffer[*position] = (char) BASE & (numReadings >> 16);
	*position += 1;	
	charBuffer[*position] = (char) BASE & (numReadings >> 24);
	*position += 1;	
}


void setFreq (char* charBuffer ,int* position, unsigned int freq)
{
		//instruction char
	charBuffer[*position] = SET_FREQ;	  
	*position += 1;

	unsigned int hperiod = (unsigned int) (8000000UL/freq);	//assuming freq ~ 1000Hz, 2 chars will suffice
	unsigned int delc1 = (unsigned int)(0.3591/3.14159*hperiod);	//0.3591 is what used to be 'a'
	unsigned int delc2 = hperiod-2*delc1;

	 
	charBuffer[*position] = (char) BASE & delc1;
	*position += 1;
	 
	charBuffer[*position] = (char) BASE & (delc1 >> 8);
	*position += 1;

	 
	charBuffer[*position] = (char) BASE & delc2;
	*position += 1;
	 
	charBuffer[*position] = (char) BASE & (delc2 >> 8);
	*position += 1;

	 
	charBuffer[*position] = (char) BASE & hperiod;
	*position += 1;					//duration of a half period in clock cycles (two chars)
	 
	charBuffer[*position] = (char) BASE & (hperiod >> 8);
	*position += 1;
}
void setPulsePins (char* charBuffer ,int* position, unsigned int pin1,unsigned int pin2)
{
					//instruction char
	charBuffer[*position] =  SET_PULSE_PINS;

	*position += 1;
	
	charBuffer[*position] =  (char) pin1 & BASE;
	*position += 1;

	 
	charBuffer[*position] = (char) pin2 & BASE;
	*position += 1;
}

void loop(char* charBuffer ,int* position, unsigned int numLoops)
{
					//instruction char
	charBuffer[*position] = LOOP;
	*position += 1;

	
	charBuffer[*position] =  (char) BASE & numLoops;
	*position += 1;					//number of times to loop
	
	charBuffer[*position] =  (char) BASE & (numLoops >> 8);
	*position += 1;
}

void endLoop(char* charBuffer ,int* position)
{
					//instruction char
	charBuffer[*position] = END_LOOP;
	*position += 1;
}

void ardSync(char* charBuffer ,int* position)
{
					//instruction char
	charBuffer[*position] = SYNC;
	*position += 1;
}

