/*
  arduino_nmr.c  Copyright 2010 Carl Michal


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.


 */


/* sends a P, then reads data and spits out as ascii.

*/

#include <stdio.h>
#include <termios.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#define NSCAN 16000
#define MAX_DATA 65536*4
// cu -l /dev/ttyUSB0 -s 2000000

// how long between scans.
#define US_DELAY 300000

int my_read(int fd, char* buff, long num){

  long j,count=0;

  do{
    j=read(fd,buff+count,num-count);
    count += j;
  }while (count < num);
  return num;

}


main(){

  int num=0;
int fd0;
struct termios myterm;
 int j,i,k,ns,num_read;
 unsigned short int *buff=NULL;
 unsigned long np;
 char *cbuff,sw;
 unsigned int time;
 char sbuff[50];
 FILE *outfile;
 long data_avg[MAX_DATA];
 float data_ft[MAX_DATA*4];

 fd0 = open("/dev/ttyUSB0", O_RDWR|O_NOCTTY);

 if (fd0 <0){
   perror("Can't open port error");
   exit(1);
 }
 tcgetattr( fd0, &myterm );

 for(i=0;i<MAX_DATA;i++) data_avg[i]=0;

 for(k=0;k<NSCAN;k++){

   myterm.c_iflag = 0;
   myterm.c_oflag = CR0 ;
   myterm.c_cflag = CSTOPB | CS8  | CLOCAL | CREAD | B2000000;
   myterm.c_lflag =ICANON;  // this screws up binary transfers, see below
   
   myterm.c_cc[VMIN]=1; 
   // read should't return until there's at lesat one character.
   
   j= cfsetospeed( &myterm, B2000000 ); 
   if (j<0) perror("error setting speed");
   
   j= cfsetispeed( &myterm, B2000000 ); 
   if (j!=0) perror("error setting speed");
   
   j=tcsetattr( fd0, TCSANOW, &myterm );
   if (j<0) perror("error setting attributes");
   
   tcflush(fd0,TCIOFLUSH);
   
   fprintf(stderr,"waiting for prompt:\n");
   // this is text mode:
   do{
     j = read(fd0,sbuff,50);
     sbuff[j]=0;
     fprintf(stderr,"got: %s\n",sbuff);
   } while(strncmp(sbuff,"send P key to start.",20) != 0);

   myterm.c_lflag =0;  // get rid of ICANON for binary:
   j=tcsetattr( fd0, TCSANOW, &myterm );
   if (j<0) perror("error setting attributes");
   
   tcflush(fd0,TCIOFLUSH);

   
   //   fprintf(stderr,"about to write:\n");
   write(fd0,"P\r\n",3);
   
   fprintf(stderr,"scan started\n");
   
   // first read four bytes for np
   
   j=my_read(fd0,(char *) &np,4);
   fprintf(stderr,"reading %lu data points\n",np);
   if (buff == NULL)
     buff=(unsigned short *) malloc(np*2+4); // four extra bytes for time at end

   cbuff = (char *) buff;
   my_read(fd0,cbuff,2*np);

   // get timing for received data.
   my_read(fd0,(char *)&time,4);
   fprintf(stderr,"time is %i us, that's: %g Hz\n",time,((float) np)*1000000/ time);

   // signal average:
   if (num % 2 == 0)
     for(i=0;i<np;i++) data_avg[i] += buff[i];
   else
     for(i=0;i<np;i++) data_avg[i] -= buff[i];
   num +=1;
   for(i=0;i<np;i++){
     data_ft[2*i] = data_avg[i];
     data_ft[2*i+1] =  0.;
   } 
   // get rid of zero offset:
   four1(data_ft-1,np,1);
   data_ft[0]=0;
   four1(data_ft-1,np,-1);

//zero fill
   for(i=np;i<np*2;i++){
     data_ft[2*i]=0;
     data_ft[2*i+1] = 0;
   }
   four1(data_ft-1,np*2,1);
   data_ft[0] = 0.; // baseline correct
   outfile=fopen("dump.txt","w");
   fprintf(outfile,"# %i scans, %i us extra delay\n",k+1,US_DELAY);
   // fprintf(stderr,"read: %i bytes\n",num_read);
   for(i=0;i<np;i++)
     fprintf(outfile,"%i %li %f %f %f\n",i,data_avg[i],data_ft[2*i]/(np/2),data_ft[2*i+1]/(np/2),((float) np)*1000000/ time*i/np/2.  );
   fclose(outfile);
   fprintf(stderr,"done scan %i of %i\n",k+1,NSCAN);
   if (k<NSCAN-1)
     usleep(US_DELAY);
 }


     
 free(buff);
   myterm.c_lflag =ICANON ; 
   j=tcsetattr( fd0, TCSADRAIN, &myterm );
   if (j<0) perror("error setting attributes");


close(fd0);
}

