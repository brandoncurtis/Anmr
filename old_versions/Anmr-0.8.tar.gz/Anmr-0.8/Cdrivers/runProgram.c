/*
	Name: runProgram.c
	Programmer: Daniel Hon Kit Chong and Carl Michal
	Date Altered: Jan  2012
	For reading data

Error messages in here are terrible...

arduino uno has a problem.  Serial port resets when opened no matter what I do...
looks like this is hardcoded into the cdc-acm driver.

try this:

socat   PTY:raw,echo=0,link=/tmp/com1,clocal,b2000000,cs8,ixon=0,icrnl=0,icanon=0,opost=0,isig=0 /dev/ttyACM0,raw,echo=0,b2000000,clocal,cs8,ixon=0,icrnl=0,icanon=0,opost=0,isig=0


runProgram could use a timeout protection - right now it will sit and wait forever for the data to come...
could look for END_PROGRAM in the data stream I guess?
*/

#include "funcProto.h"
#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include "definitions.h"

int my_read(int fd, char* buff, long num){

  long j,count=0;

  do{
    j=read(fd,buff+count,num-count);
    count += j;
  }while (count < num);
  return num;

}

void readStr(int portID, char* output, int size)
/*
 *This function reads a string from the serial port,
 *stops when either end line character is found or max length is reached.
 */
{
	int i;
	char temp;
	for (i=0; i<size ; i++)
	{
		read(portID, &temp,1);
		if (temp == '\n') {
			output[i] = 0;
			printf("%s\n", output);
			return;
		}
		output[i] = temp;
	}
	output[size-1] = 0;
	//printf("%s\n", output);
}

int runProgram ( int portID, char* fileName)
{
	FILE * outFile;
	int counter =0,dummy;
	short *bptr;
	int i,used,totalPoints;
	unsigned int numReadings=0;
	int numIterations = 0;
	int *olddata=NULL,*newdata;
	char sbuff[50];	
	short idat;

	// read in the old data
	outFile = fopen(fileName, "r");
	counter = 0;
	if(outFile){		//then file exists currently
	  while(fgets(sbuff,50,outFile) != NULL ){
	   if (sbuff[0] == '#'){
	      sscanf(sbuff+1,"%i",&numIterations);
	      //	      printf("got %i old iterations\n",numIterations);
	    }
	   else
	     counter += sscanf(sbuff,"%i",&dummy); // count how many lines we can read in.
	  }
	  
	  if (counter > 0){
	    rewind(outFile);
	    olddata = (int *) malloc(sizeof(int)*counter);
	    if (numIterations > 0)
	      fgets(sbuff,50,outFile);// if we found a number above, store the data this time.
	    for(i=0;i<counter;i++)
	      fscanf(outFile,"%i",&olddata[i]);
	    //	    printf("read in %i points from file\n",counter);
	  }
	  fclose(outFile);
	}
	

	tcflush(portID,TCIOFLUSH);
	
	sbuff[0] = QUERY;
	write(portID,sbuff,1);
	readStr(portID, sbuff, 50);
	if (strncmp("ANMR v0.8, Ready", sbuff,16) != 0){
	  printf("Didn't find ready signal!\n");
	  return -4;
	}
	//	printf("Got Ready signal\n");

	// read in the old data file if it exists.

	go(portID);
	readStr(portID, sbuff, 50);

	if (strncmp("Executing instructions", sbuff,22) != 0){
	    printf("unknown string received: %s\n",sbuff);
	    return -3;
	  }

	printf("\nEXECUTION STARTED\n");
	/* testing - paried with mods in arduinoCode
	    my_read(portID,(char *) &idat,2);
	    printf("pulse end: %i\n",idat);
	    my_read(portID,(char *) &idat,2);
	    printf("pulse end: %i\n",idat);
	*/
	
	totalPoints = 0;
	newdata = malloc(4); //we'll expand this as needed
	used = 0;
	do{
	  readStr(portID, sbuff, 50);
	  //	  printf("got: %s\n",sbuff);
	  if (strncmp(sbuff,"DAT",3) == 0){
	    //	    printf("got DAT, how many points?\n");
	    // get number of points.
	    // read raw binary.  x86 and ATMega 328 are both little endian.
	    
	    my_read(portID,(char *) &numReadings,4);
	    //	    printf("expecting %i points\n",numReadings);

	    /* testing - paired with mods to arduinoCode
	    my_read(portID,(char *) &idat,2);
	    printf("read start: %i\n",idat);
	    */
	    totalPoints += numReadings;
	    //	    printf("total points is now: %i\n",totalPoints);
	    bptr = (short *) malloc(numReadings*2);

	    // read the data:	    
	    my_read(portID,(char *) bptr,2*numReadings);
	    //	    printf("got %i points back from arduino\n",numReadings);
	    // add these to the old ones, if they exist
	    newdata = realloc(newdata,totalPoints*sizeof(int));
	    for (i=0;i<numReadings;i++){
	      if (used < counter){
		newdata[used] = bptr[i]+olddata[used];
		used += 1;
	      }
	      else{
		newdata[used] = bptr[i];
		used += 1;
	      }
	    }	
	    free(bptr);
	    //	    printf("used is now: %i\n",used);
	  }
	}while (strncmp(sbuff,"DAT",3) == 0);
	if (strncmp(sbuff,"EOP",3) != 0){
	  printf("received unexpected response: %s\n",sbuff);
	  return -9;	  
	}
	    

	    
// write out the data file

	outFile = fopen(fileName,"w");
	if (outFile == NULL){
	  printf("couldn't open file for write\n");
	  return -4;
	}
		// we want to add the iteration number to the top of the list
		// remember, we add one because this is another iteration 
	fprintf( outFile, "#%d\n", numIterations + 1);
	printf("going to write: %i points\n",totalPoints);
	for (i=0; i<totalPoints; i++)
	  {
	    fprintf( outFile, "%d\n", newdata[i]);
	  }

	free(newdata);
	if (olddata != NULL) free(olddata);
	fclose(outFile);
	
	return 1;
}

int main (int argc, char *argv[])
/*
	return value interpretations:
	-1 = Incorrect number of arguments
	-2 = Cannot open port
	-3 = Did not execute all runs
	-4 = Not receiving micro-controller
	-5 = file io error
*/
{
	if (argc != 3){
		printf("Incorrect number of arguments. Terminating program");
		return -1;
	}
	int j;

	char portName[300];
	//	sscanf (argv[1], "%s", portName);
	strcpy(portName,argv[1]);

	char fileName[300];
	//	sscanf (argv[2], "%s", fileName);
	strcpy(fileName,argv[2]);

	int fd0;
	struct termios myterm;

	fd0 = open(portName, O_RDWR|O_NOCTTY);

	if (fd0 <0){
		perror("Can't open port error");
		return -2;
	}

	tcgetattr( fd0, &myterm );

	myterm.c_iflag = 0;
	myterm.c_oflag = CR0 ;
	myterm.c_cflag =  CS8  | CLOCAL | CREAD | B1000000;
	myterm.c_cc[VMIN]=1; 
	
	j= cfsetospeed( &myterm, B1000000 ); 
	if (j<0) perror("error setting speed");
	
	j= cfsetispeed( &myterm, B1000000 ); 
	if (j!=0) perror("error setting speed");
	
	j=tcsetattr( fd0, TCSANOW, &myterm );
	if (j<0) perror("error setting attributes");
	
 	

	int returnVal = runProgram(fd0, fileName);

	close(fd0);

	if (returnVal == 0)	//microcontroller busy
	  return -4; 
	else if (returnVal < 0)
		return -3;
	return 1;
	
}
