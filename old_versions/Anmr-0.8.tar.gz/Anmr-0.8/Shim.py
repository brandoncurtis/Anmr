#!/usr/bin/python2.7

from __future__ import division
import shutil
import gobject
import signal
import struct
import gc

import matplotlib.artist as Artist
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.figure import Figure
from matplotlib.backends.backend_gtkagg import FigureCanvasGTKAgg as FigureCanvas

from anmr_common import *

PROG_NAME="/tmp/funcgen-prog.txt"
TMP_DATA="/tmp/funcgen-data.txt"
RAW_DATA="/tmp/funcgen-data.raw"



class plotWindow:
	def __init__(self,title):
		#title is the title of the window.

		self.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
		self.window.set_icon_from_file("/usr/local/share/Anmr/Shim-icon.svg")
		vbox = gtk.VBox(False)
		self.window.add(vbox)
		self.window.set_size_request(600,400)
		self.window.set_title(title)
		
		self.fig = Figure(figsize=(4,3), dpi=100)
		self.ax = self.fig.add_subplot(111)
		self.ax.set_position([0.2, 0.2, 0.7, 0.7])
		self.canvas = FigureCanvas(self.fig)  # a gtk.DrawingArea
		vbox.pack_start(self.canvas, True, True)
		
		self.ax.set_xlabel("Shim dial value")
		self.ax.set_ylabel("FWQM")


	def updatePlot(self,xmin,xmax,ymin,ymax,xvals,yvals,name): 
		plotWin.ax.cla() # clear out what was there.
		plotWin.ax.set_xlim([xmin,xmax])
		plotWin.ax.set_ylim([ymin,ymax])
		plotWin.ax.set_xlabel(name+ " shim dial value")
		plotWin.ax.set_ylabel("FWQM")
		plotWin.ax.plot(xvals,yvals,'bo')

		self.canvas.draw_idle()
		return False


def do_a_shim(s0,q0,name,a):
#sval is the starting value of the shim, qval is the starting FWQM value, and name is the name of the shim to adjust
# A is the coefficient of the quadratic term expected in the equation: FWQM = sqrt(A*(x-x0)**2+c)



	# how big a step to make?
	svals = numpy.zeros(5)
	qvals = numpy.zeros(5) # max of 5 points?
	svals[0] = s0
	qvals[0] = q0
	num_p = 1

	step_size = q0/numpy.sqrt(a)/1.25 # go most of the way...
	svals[1] = round(s0 + step_size,2)
	print "step size is: ",step_size

# get the plot ready:
	xmax = svals[0] + 1.2*step_size
	xmin = svals[0] - 1.2*step_size
	ymax = qvals[0] * 1.2
	ymin = qvals[0] /1.2
	plotWin.updatePlot(xmin,xmax,ymin,ymax,svals[0:num_p],qvals[0:num_p],name)


	# start by always going up first
	going_up = True
	label.set_text("1: Set the "+name+" dial to "+str(svals[1]))
	fwqmButton.hide()
	response = dialog.run()
	if response == gtk.RESPONSE_DELETE_EVENT:
		exit()

	fwqmButton.show()
        label.set_text("Now collect a spectrum and enter the FWQM below")
        response = dialog.run()
        if response == gtk.RESPONSE_DELETE_EVENT:
		exit()


        qvals[1] = fwqmAdjust.get_value()
	num_p += 1
# plot the point
	if qvals[1] > ymax:
		ymax = qvals[1] + (qvals[1] - ymax)*0.2
	if qvals[1] < ymin:
		ymin = qvals[1] - (ymin - qvals[1])*0.2
	plotWin.updatePlot(xmin,xmax,ymin,ymax,svals[0:num_p],qvals[0:num_p],name)


# if it's better, keep going in same direction, if its worse, go the other way.
	if qvals[1] < qvals[0]:
		svals[2] = round(svals[1]+step_size,2)
		xmax += step_size
		xmin += step_size
	else:
		going_up = False
		svals[2] = round(svals[0]-step_size,2)
	label.set_text("2: Set the "+name+" dial to "+str(svals[2]))
	fwqmButton.hide()
	response = dialog.run()
	if response == gtk.RESPONSE_DELETE_EVENT:
		exit()

	label.set_text("Now collect a spectrum and enter the FWQM below")

	fwqmButton.show()
	response = dialog.run()
	if response == gtk.RESPONSE_DELETE_EVENT:
		exit()
	qvals[2] = fwqmAdjust.get_value()
	num_p += 1
# plot the point
	if qvals[2] > ymax:
		ymax = qvals[2] + (qvals[2] - ymax)*0.2
	if qvals[2] < ymin:
		ymin = qvals[2] - (ymin - qvals[2])*0.2
	plotWin.updatePlot(xmin,xmax,ymin,ymax,svals[0:num_p],qvals[0:num_p],name)


#if we were better the second time but worse the first, we need one more point:
# this is if going up made it worse, but going down made it better
	if qvals[2] < qvals[0] and qvals[1] > qvals[0]:
		xmin -= step_size
		svals[3] = round(svals[2]-step_size,2)
		label.set_text("3: Set the "+name+" dial to "+str(svals[3]))
		fwqmButton.hide()
		response = dialog.run()
		if response == gtk.RESPONSE_DELETE_EVENT:
			exit()
		label.set_text("Now collect a spectrum and enter the FWQM below")
		fwqmButton.show()
		response = dialog.run()
		if response == gtk.RESPONSE_DELETE_EVENT:
			exit()
		qvals[3] = fwqmAdjust.get_value()
		num_p += 1
#plot the point:
		if qvals[3] > ymax:
			ymax = qvals[3] + (qvals[3] - ymax)*0.2
		if qvals[3] < ymin:
			ymin = qvals[3] - (ymin - qvals[3])*0.2
		plotWin.updatePlot(xmin,xmax,ymin,ymax,svals[0:num_p],qvals[0:num_p],name)

#now, in either case of going up or down, if the last point is the best, do one more.
	if qvals[num_p-1] == numpy.amin(qvals[0:num_p]):
		if going_up:
			xmax += step_size
			svals[num_p] = round(svals[num_p-1]+step_size,2)
		else:
			xmin -= step_size
			svals[num_p] = round(svals[num_p-1]-step_size,2)
		label.set_text("5: Set the "+name+" dial to "+str(svals[num_p]))
		fwqmButton.hide()
		response = dialog.run()
		if response == gtk.RESPONSE_DELETE_EVENT:
			exit()
		label.set_text("Now collect a spectrum and enter the FWQM below")
		fwqmButton.show()
		response = dialog.run()
		if response == gtk.RESPONSE_DELETE_EVENT:
			exit()
		qvals[num_p] = fwqmAdjust.get_value()
		num_p += 1
#plot the point:
		if qvals[num_p-1] > ymax:
			ymax = qvals[num_p-1] + (qvals[num_p-1] - ymax)*0.2
		if qvals[3] < ymin:
			ymin = qvals[num_p-1] - (ymin - qvals[num_p-1])*0.2
		plotWin.updatePlot(xmin,xmax,ymin,ymax,svals[0:num_p],qvals[0:num_p],name)


	q2 = qvals*qvals # should be fitting squares - for second moments.
	print "have ",num_p," points"
	s40 = numpy.sum(svals[0:num_p]*svals[0:num_p]*svals[0:num_p]*svals[0:num_p])
	s30 = numpy.sum(svals[0:num_p]*svals[0:num_p]*svals[0:num_p])
	s20 = numpy.sum(svals[0:num_p]*svals[0:num_p])
	s10 = numpy.sum(svals[0:num_p])
	s21 = numpy.sum(svals[0:num_p]*svals[0:num_p]*q2[0:num_p])
	s11 = numpy.sum(svals[0:num_p]*q2[0:num_p])
	s01 = numpy.sum(q2[0:num_p])
	s00 = num_p	
	# now get the fit:
	denom = s00*s20*s40-s10*s10*s40-s00*s30*s30+2*s10*s20*s30-s20*s20*s20
	a=0.
	if denom != 0:
		a = (s01*s10*s30-s11*s00*s30-s01*s20*s20+s11*s10*s20+s21*s00*s20-s21*s10*s10)/denom
		b = (s11*s00*s40-s01*s10*s40+s01*s20*s30-s21*s00*s30-s11*s20*s20+s21*s10*s20)/denom
		c = (s01*s20*s40-s11*s10*s40-s01*s30*s30+s11*s20*s30+s21*s10*s30-s21*s20*s20)/denom
		print "fit says: a ",a," b: ",b," c: ",c," min at: ",-b/2/a," min of: ",c-a*b*b/4/a/a
		best = round(-b/2/a,2)
	
#	ymax = numpy.amax(qvals[0:num_p])
#	xmax = numpy.amax(svals[0:num_p])
#	xmin = numpy.amin(svals[0:num_p])
#	ymin = numpy.amin(qvals[0:num_p])
	if a <= 0.1 or best > xmax or best < xmin or denom == 0: # then our parabola is upside down or we're trying to go out of range, or the denominator was 0.
		sf = round(svals[0],2)
		bailed_out = True
	else:
		sf = best
		bailed_out = False
		if c-a*b*b/4/a/a < ymin:
			ymin = c-a*b*b/4/a/a
## plot it:

#	xd = xmax-xmin
#	yd = ymax-ymin
#	if xd == 0:
#		xd = 0.1
#	if yd == 0:
#		yd= 0.1
#	xmax = xmax+0.2*xd
#	xmin = xmin-0.2*xd
#	ymax = ymax+0.2*yd
#	ymin = ymin-0.2*yd

	if bailed_out == False :
#plot the parabola fit and a red line for where we hope to be
		xr = numpy.linspace(xmin,xmax,50)
		yr = numpy.sqrt(a*xr*xr+b*xr+c)
		plotWin.line = Line2D(xr,yr)
		plotWin.ax.add_line(plotWin.line)
		plotWin.line = plotWin.ax.axvline(sf,color = 'r')
		plotWin.canvas.draw_idle()

		label.set_text("4: Set the "+name+" dial to "+str(sf)+"\nThis is the estimated best position.")

	else:
		label.set_text("4: Set the "+name+" dial to "+str(sf)+"\nThis is the starting value because the data\ndid not conform to expectations.\nIs the signal to noise adequate?")
	fwqmButton.hide()
	response = dialog.run()
	if response == gtk.RESPONSE_DELETE_EVENT:
		exit()
	label.set_text("Now collect a spectrum and enter the FWQM below")
	fwqmButton.show()
	response = dialog.run()
	if response == gtk.RESPONSE_DELETE_EVENT:
		exit()
	qf = fwqmAdjust.get_value()
	if qf > qvals[0]*1.2 and sf != svals[0]: # we're at least not too much worse:
		print "Help, we're worse, should go back to start val!"
	return(sf,qf)
 	
		
def pltWinClose(self, widget, junk,pltWin):
	print "tried to close window"
	return True # don't allow to close

#print __name__
if __name__ == "__main__":


# build a plot window
	plotWin = plotWindow("Shimming")
#catch delete events.
	connection = plotWin.window.connect("delete_event",pltWinClose,plotWin)
	plotWin.first = True
	plotWin.window.show_all()


	dialog = gtk.Dialog("Shimming Oracle",None,0,(gtk.STOCK_OK,gtk.RESPONSE_ACCEPT))
	dialog.set_transient_for(plotWin.window)
	position = dialog.get_position()
	dialog.move(position[0], position[1]+250)  

	label = gtk.Label("Enter values of the X1, Z1, and Y1 gradient\ncurrent dials (in that order) and hit OK")
	dialog.vbox.pack_start(label)

	hbox = gtk.HBox()
	dialog.vbox.pack_start(hbox)

	shimAdjust1 = gtk.Adjustment(value = 5.00, lower = 0, upper = 10.0, step_incr = 0.01)
	shimButton1 = gtk.SpinButton(shimAdjust1, 0.1, 2) #args are climb_rate and digits
	hbox.pack_start(shimButton1)

	shimAdjust2 = gtk.Adjustment(value = 5.00, lower = 0, upper = 10.0, step_incr = 0.01)
	shimButton2 = gtk.SpinButton(shimAdjust2, 0.1, 2) #args are climb_rate and digits
	hbox.pack_start(shimButton2)

	shimAdjust3 = gtk.Adjustment(value = 5.00, lower = 0, upper = 10.0, step_incr = 0.01)
	shimButton3 = gtk.SpinButton(shimAdjust3, 0.1, 2) #args are climb_rate and digits
	hbox.pack_start(shimButton3)
		
	dialog.show_all()
	response = dialog.run()
	if response == gtk.RESPONSE_DELETE_EVENT:
		exit()
	if response == gtk.RESPONSE_ACCEPT:
		print "got accept"
	print "got entry val:",shimAdjust1.get_value()
	print "got entry val:",shimAdjust2.get_value()
	print "got entry val:",shimAdjust3.get_value()


	s1 = shimAdjust1.get_value()
	s2 = shimAdjust2.get_value()
	s3 = shimAdjust3.get_value()

	fwqmAdjust = gtk.Adjustment(value = 5.00, lower = 0, upper = 99.0, step_incr = 0.01)
	fwqmButton = gtk.SpinButton(fwqmAdjust, 0.1, 2) #args are climb_rate and digits
	hbox.pack_start(fwqmButton)
	fwqmButton.show()

	label.set_text("Enter the starting FWQM")
	shimButton3.hide()
	shimButton2.hide()
	shimButton1.hide()
	response = dialog.run()
	if response == gtk.RESPONSE_DELETE_EVENT:
		exit()
	q1 = fwqmButton.get_value()
	print "got starting Q:",q1
# now loop through the three shims

	(s1,q2) = do_a_shim(s1,q1,"X1",500)
	(s2,q3) = do_a_shim(s2,q2,"Z1",300)
	(s3,q1) = do_a_shim(s3,q3,"Y1",400)

	(s1,q2) = do_a_shim(s1,q1,"X1",500)
	(s2,q3) = do_a_shim(s2,q2,"Z1",320)
	(s3,q1) = do_a_shim(s3,q3,"Y1",400)


	fwqmButton.hide()
	label.set_text("If all went well, the FWHM is now approximately 1 Hz\nIf it is greater than 1.5 Hz, you can try\nstarting this program again to optimize the currents further.")
	response = dialog.run()



