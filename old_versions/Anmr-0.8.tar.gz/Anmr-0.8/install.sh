#!/bin/sh
# this all works for Ubuntu 11.04 not tested elsewhere.


#user's home directory:
export HDIR=/home/student

# need to be executed as root, in the directory where this was unpacked
#get rid of any previous installation:
rm -rf /usr/local/share/Anmr
mkdir /usr/local/share/Anmr

#install the code, python, C (source and executables), arduino, and pulse programs:
mv Anmr.py /usr/local/bin/
mv FuncGen.py /usr/local/bin/
mv Shim.py /usr/local/bin/
mv anmr_common.py /usr/local/bin/

mv Cdrivers /usr/local/share/Anmr/

mv arduinoCode /usr/local/share/Anmr/

mv PulsePrograms /usr/local/share/Anmr/

#fix permissions so users can build and download the arduino code
chmod ugo+rwx /usr/local/share/Anmr/arduinoCode
chmod ugo+rwx /usr/local/share/Anmr/arduinoCode/build

#icons:
mv FuncGen-icon.svg /usr/local/share/Anmr/
mv Shim-icon.svg /usr/local/share/Anmr/
mv Anmr-icon.svg /usr/local/share/Anmr/

#.desktop files for our python progs to work nicely on the menus
mv FuncGen.desktop /usr/local/share/applications/
mv Anmr.desktop /usr/local/share/applications/
mv Shim.desktop /usr/local/share/applications/


#if using CairoDock:
#mkdir -p $HDIR/.config/cairo-dock/current_theme/launchers
#mv *launcher*.desktop $HDIR/.config/cairo-dock/current_theme/launchers/
#chmod ugo-w $HDIR/.config/cairo-dock/current_theme/launchers/01launcher.desktop
#chmod ugo-w $HDIR/.config/cairo-dock/current_theme/launchers/02launcher.desktop
#chmod ugo-w $HDIR/.config/cairo-dock/current_theme/launchers/03launcher.desktop
#chmod ugo-w $HDIR/.config/cairo-dock/current_theme/launchers/04launcher.desktop

#hack for scons to work with arduino 1.00 (in Ubuntu 12.04)

ln -s /usr/share/arduino/hardware/arduino/variants/standard/pins_arduino.h /usr/share/arduino/hardware/arduino/cores/arduino

#create a data directory, and populate with some sample data
mkdir -p $HDIR/anmr-data
mv anmr-data/00shimmed $HDIR/anmr-data/
mv anmr-data/01image $HDIR/anmr-data/

echo ""
echo "Ensure that the user in the dialout group"
echo ""
echo "You may need to log out and in again for Anmr, FuncGen, and Shim to appear in the menus"
